import { Text, View } from "react-native"
import Estilo from '../components/Estilo'
import { Button } from "react-native"
import Counter from "../components/Counter"
import InstanciaPessoa from "../components/InstanciaPessoa"

export default props => {

    return(
        <View style={{flex: 1, justifyContent: 'center', alignItems:'center'}}>
            <Text style={Estilo.textMedium}>Tela de chamada de componentes!</Text>

            {/*<Counter />*/}
            <InstanciaPessoa />

            <Button 
                title="Voltar"
                onPress={()=>props.navigation.goBack()}
            />
        </View>
    )
}