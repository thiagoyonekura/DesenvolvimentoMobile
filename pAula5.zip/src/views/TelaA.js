import TextCentral from '../components/TextCentral'

export default props =>(
    <TextCentral corFundo='#e53935'>
        Tela A
    </TextCentral>
)