import TextCentral from "../components/TextCentral";


export default props =>(
    <TextCentral corFundo="#3b82c4">
        Tela B
    </TextCentral>
)