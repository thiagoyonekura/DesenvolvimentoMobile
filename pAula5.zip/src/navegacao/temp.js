import { View } from "react-native";



<View>
    <Text>
        Xpto
    </Text>
</View>