import { Text, FlatList } from "react-native"
import Estilo from '../Estilo'
import produtos from './Produtos'

export default props => {
    function geraLista(){
        return <FlatList 
                    data={produtos}
                    renderItem={ 
                        renderizaProduto
                    }
                    keyExtractor={ (i)=>`${i.id}` }
                />
    }

    const renderizaProduto = ({item: prod})=> {
        return(
            <Text style={Estilo.textoPequeno}>
                {prod.id} - 
                {prod.nome} - 
                R$ {prod.valor}
            </Text>
        )
    }
    
    return(
        <>
            <Text style={[Estilo.textoMedio, Estilo.centraliza]}>Lista de Produtos</Text>
            {
               geraLista() 
            }
        </>
    )
}