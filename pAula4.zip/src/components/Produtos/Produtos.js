export default [
    {id: 1, nome: 'Notebook Avell Gamer', valor: 5500.00},
    {id: 2, nome: 'Mouse Razor', valor: 300.00},
    {id: 3, nome: 'Teclado Mecânico com RGB', valor: 289.00},
    {id: 4, nome: 'Headset HyperX', valor: 423.12},
    {id: 5, nome: 'Monitor 8k curvo', valor: 8300.45},
    {id: 6, nome: 'MousePad Gamer', valor: 123.45},
]