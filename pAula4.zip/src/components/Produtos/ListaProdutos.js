import { Text } from "react-native"
import Estilo from '../Estilo'
import produtos from './Produtos'

export default props => {
    function geraLista(){
        return (
            produtos.map(
                (p) => {
                    return <Text style={Estilo.textoPequeno} key={p.id}>Id: {p.id} - {p.nome} - {p.valor} </Text>
                }
            )
        )
    }
    
    return(
        <>
            <Text style={[Estilo.textoMedio, Estilo.centraliza]}>Lista de Produtos</Text>
            {
               geraLista() 
            }
        </>
    )
}