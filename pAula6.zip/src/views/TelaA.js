import TextoCentral from '../components/TextoCentral'

export default props => (
    <TextoCentral corFundo='#e53935'>
        Tela A
    </TextoCentral>
)