import TextoCentral from '../components/TextoCentral'

export default props => (
    <TextoCentral corFundo='#338264'>
        Tela B
    </TextoCentral>
)