import { Button, View } from 'react-native'
import TextoCentral from '../components/TextoCentral'

export default props => (
    <View style={{flex: 1}}>
        <View style={{flexDirection: 'row', justifyContent: 'flex-start'}}>
            <Button
                title='Menu'
                onPress={
                    ()=>{
                        props.navigation.openDrawer()

                        setTimeout(()=>{props.navigation.closeDrawer()}, 4 * 1000)
                    }
                }
            />
        </View>
        <View style={{flex: 1}}>
            <TextoCentral corFundo='blue'>
                Tela D
            </TextoCentral>
        </View>
    </View>
)