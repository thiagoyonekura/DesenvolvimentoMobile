export default [
    {
        id: 1,
        name: 'Lewis Hamilton',
        email: 'l_hamilton@gmail.com',
        avatarURL: 'https://cdn.pixabay.com/photo/2016/03/31/19/58/avatar-1295430_1280.png',
    },
    {
        id: 2,
        name: 'Max Verstappen',
        email: 'max_verst1@hotmail.com',
        avatarURL: 'https://cdn.pixabay.com/photo/2013/07/12/16/34/vampire-151178_1280.png',
    },
    {
        id: 3,
        name: 'Charles Leclerc',
        email: 'lec_dagalera@ferrari.com',
        avatarURL: 'https://cdn.pixabay.com/photo/2013/07/12/19/15/gangster-154425_1280.png',
    },
    {
        id: 4,
        name: 'Sergio Perez',
        email: 'perez_rbr@rbrracing.com',
        avatarURL: 'https://cdn.pixabay.com/photo/2017/08/14/08/39/emoji-2639738_1280.png',
    },
    {
        id: 5,
        name: 'George Russel',
        email: 'jorgao_da_massa@hotmail.com',
        avatarURL: 'https://cdn.pixabay.com/photo/2020/06/04/12/55/emoji-5258611_1280.png',
    },
]