import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { Image, StyleSheet, Text, TextInput, View } from 'react-native';
import BotaoGrandeVerde from './src/components/BotaoGrandeVerde';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.xpto}>Meu primeiro APP</Text>

      <Image source={require('./assets/logo.jpg')} style={styles.logoPrincipal} />


      <TextInput 
        placeholder='insira o login' 
        style={styles.inputLogin} 
        keyboardType={'default'}
      />
      <TextInput 
        placeholder='digite a senha' 
        style={styles.inputLogin} 
        secureTextEntry={true}
      />
      <BotaoGrandeVerde textoDoBotao={'Acessar o APP'} />



      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  xpto:{
    color: 'blue',
    fontSize: 32,
  },
  logoPrincipal:{
    height: 200,
    width: 200,
  },
  inputLogin:{
    height: 60,
    width: 250,
    fontSize: 25,
    marginTop: 5,
  }
});
