const mysql = require('mysql');

const db = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'toor',
	database: 'conecta_app'
});

db.connect((err)=>{
	if(err){
		console.error('erro ao conectar com o banco: ', err);
	}else{
		console.log('Conexão com o SGBD realizada com sucesso!');
	}
});

module.exports = db;