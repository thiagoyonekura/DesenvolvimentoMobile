const express = require('express');
const app = express();
const port = 3000;
app.use(express.json());
const db = require('./config/db');


app.get('/', (req, res) => {
	res.send('Olá mundo!');
});

app.get('/testabanco', (req, res)=>{
	db.query('select * from usuario', (err, results)=>{
		if(err){
			console.error('Erro na consulta: ', err);
			res.status(500).send('Erro na consulta')
		}else{
			res.status(200).json(results);
		}
	})
})

app.get('/api/usuarios', (req, res)=>{
	const data = {
		id: 1,
		login: 'usuario_teste',
		senha: '123456',
		nome: 'Fulano de tal'
	}
	
	const usuarios = require('./usuarios.json');

	//res.status(200).json(usuarios);
	
	db.query('select * from usuario', (err, results)=>{
		if(err){
			console.error('Erro na consulta: ', err);
			res.status(500).send('Erro na consulta')
		}else{
			res.status(200).json(results);
		}
	})
});


app.get('/api/movies', (req, res) =>{
	const arqJson = require('./movies.json');
	res.json(arqJson);
});

app.post('/api/login', (req, res)=>{
	const {valorLogin, valorSenha} = req.body;
	
	if(valorLogin && valorSenha){
		const query = 'Select * from usuario where (usuario.login = ? and usuario.passwd = ?)';
		db.query(query, [valorLogin, valorSenha], (err, result)=>{
			if(err){
				console.error("Erro ao consultar usuário");
				res.status(500).json({message: 'Erro ao consultar usuario'})
			}else{
				console.log("Query executada!");
				if(result.length > 0){
					res.status(200).json(result);
				}else{
					res.status(500).json({message: 'Usuário e/ou senha incorretos!'});
				}
			}
		})
	}
})

app.post('/api/usuario', (req, res)=>{
	//const dados = req.body;
	const {id, user_name, email, login, passwd, avatarURL} = req.body;
	
	if(id){
		//Update
		console.log("Está atualizando");
		
		const query = 'Update usuario set user_name = ?, email = ?, login = ?, passwd = ?, avatarURL = ? where id = ?'
		db.query(query, [user_name, email, login, passwd, avatarURL, id], (err, result) => {
			if(err){
				console.error("Erro ao executar update no SGBD: ", err);
				res.status(500).json({message: 'erro na atualização no banco'});
			}else{
				console.log("Dados atualizados");
				res.status(200).json({message: 'Dados atualizados com sucesso!'});
			}
		})
		
	}else{
		//Insert
		console.log("Está inserindo");
		const query = "Insert into usuario(user_name, email, login, passwd, avatarURL) values (?, ?, ?, ?, ?)";
		db.query(query, [user_name, email, login, passwd, avatarURL], (err, result)=>{
			if(err){
				console.error("Erro ao executar inserção no SGBD: ", err);
				res.status(500).json({message: 'erro na inserção no banco'});
			}else{
				res.status(200).json({message: 'Dados inseridos com sucesso!'});
			}
		})
	}
	
	//res.status(200).json({mensagem: 'POST realizado!'});
});

app.delete('/api/usuario/:pId', (req, res) => {
	const id = req.params.pId;
	
	if(id){
		console.log("removendo id: ", id);
		const query = "delete from usuario where id = ?"
		db.query(query, id, (err, result)=>{
			if(err){
				console.error("Erro ao apagar registro");
				res.status(500).json({message: 'erro ao remover usuario'})
			}else{
				res.status(200).json({message: 'usuario removido com sucesso'})
			}
		})
	}
})

app.put('/api/usuario', (req, res)=>{
	const {id, user_name, email, login, avatarURL, passwd} = req.body;
	
	if(id){
		const query = 'update usuario set user_name = ?, email = ?, login = ?, passwd = ?, avatarURL = ? where id = ?'
		db.query(query, [user_name, email, login, passwd, avatarURL, id], (err, result)=>{
			if(err){
				console.error("erro ao atualizar registro");
				res.status(500).json({message: 'erro ao atualizar registro'})
			}else{
				res.status(200).json({message: 'registro atualizado com sucesso'})
			}
		})
	}
})

app.post('/api/movie', (req, res)=>{
	const dados = req.body;
	console.log('Dados de filme recebido: ', dados);
	res.json({mensagem: 'POST realizado!'});
})

app.post('/api/usuarioxpto', (req, res) =>{
	const dados = req.body;
	
	console.log('Dados recebidos: ', dados);
	
	res.json({mensagem: 'Dados recebidos com sucesso!'});
});

app.listen(port, ()=>{
	console.log(`Servidor funcionando na porta: ${port}`);
})